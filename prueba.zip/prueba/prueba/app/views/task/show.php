<!DOCTYPE html>
<html>
<head>
    <title>Detalle de la Tarea</title>
</head>
<body>
    <h2><?php echo htmlspecialchars($task['title'], ENT_QUOTES, 'UTF-8'); ?></h2>
    <p><?php echo htmlspecialchars($task['description'], ENT_QUOTES, 'UTF-8'); ?></p>
    <p>Status: <?php echo htmlspecialchars($task['status'], ENT_QUOTES, 'UTF-8'); ?></p>
    <a href="/tasks">Volver</a>
</body>
</html>
