<!DOCTYPE html>
<html>
<head>
    <title>Editar Tarea</title>
</head>
<body>
    <h1>Editar Tarea</h1>
    <form action="/task/edit/<?php echo $task['id']; ?>" method="post">
        <label for="title">Título</label>
        <input type="text" name="title" id="title" value="<?php echo htmlspecialchars($task['title'], ENT_QUOTES, 'UTF-8'); ?>" required>
        
        <label for="description">Descripción</label>
        <textarea name="description" id="description" required><?php echo htmlspecialchars($task['description'], ENT_QUOTES, 'UTF-8'); ?></textarea>

        <label for="status">Estado</label>
        <select name="status" id="status">
            <option value="pending" <?php echo $task['status'] == 'pending' ? 'selected' : ''; ?>>Pendiente</option>
            <option value="completed" <?php echo $task['status'] == 'completed' ? 'selected' : ''; ?>>Completado</option>
        </select>

        <button type="submit">Guardar cambios</button>
    </form>
</body>
</html>
