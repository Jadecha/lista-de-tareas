<!DOCTYPE html>
<html>
<head>
    <title>Crear Nueva Tarea</title>
</head>
<body>
    <h1>Crear Nueva Tarea</h1>
    <form action="/prueba/task/create" method="post">
        <label for="title">Título</label>
        <input type="text" name="title" id="title" required>
        
        <label for="description">Descripción</label>
        <textarea name="description" id="description" required></textarea>

        <label for="status">Estado</label>
        <select name="status" id="status">
            <option value="pending">Pendiente</option>
            <option value="completed">Completado</option>
        </select>

        <button type="submit">Crear</button>
    </form>
</body>
</html>
