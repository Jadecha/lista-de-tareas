<?php

class TaskController
{
    private $taskModel;

    public function __construct($pdo)
    {
        $this->taskModel = new Task($pdo);
    }

    public function index()
    {
        $tasks = $this->taskModel->getAll();
        require '../app/views/task/index.php';
    }

    public function show($id)
    {
        $task = $this->taskModel->get($id);
        require '../app/views/task/show.php';
    }

    public function create()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'title' => $_POST['title'],
                'description' => $_POST['description'],
                'status' => $_POST['status'],
            ];
            $this->taskModel->create($data);
            header('Location: /prueba/tasks');
        } else {
            require '../app/views/task/create.php';
        }
    }

    public function edit($id)
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'title' => $_POST['title'],
                'description' => $_POST['description
