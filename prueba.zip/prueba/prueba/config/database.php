<?php

$host = 'localhost';
$dbname = 'task_manager';
$username = 'root';
$password = '';
$charset = 'utf8mb4';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password,$charset);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("No se pudo connectar la base de datos $dbname :" . $e->getMessage());
}

return $pdo;
?>
