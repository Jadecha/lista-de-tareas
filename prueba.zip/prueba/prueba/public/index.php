<?php

// Incluir los archivos necesarios
require '../config/database.php';
require '../app/models/Task.php';
require '../app/controllers/TaskController.php';

// Obtener la conexión a la base de datos
$pdo = require '../config/database.php';

// Instanciar el controlador de tareas
$taskController = new TaskController($pdo);

// Obtener la URL solicitada
$url = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

// Enrutamiento
if ($url == '/prueba/tasks') {
    $taskController->index();
} elseif ($url == '/prueba/task/create' && $_SERVER['REQUEST_METHOD'] == 'POST') {
    $taskController->create();
} elseif ($url == '/prueba/task/create') {
    $taskController->create();
} elseif (preg_match('/\/prueba\/task\/edit\/(\d+)/', $url, $matches)) {
    $taskController->edit($matches[1]);
} elseif (preg_match('/\/prueba\/task\/show\/(\d+)/', $url, $matches)) {
    $taskController->show($matches[1]);
} elseif (preg_match('/\/prueba\/task\/delete\/(\d+)/', $url, $matches)) {
    $taskController->delete($matches[1]);
} else {
    http_response_code(404);
    echo 'Página no encontrada';
}
?>
